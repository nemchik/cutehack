"Illegal Offset" Bug Fix on PHP v4.3.10


There are two ways of installing this, but
BE SURE TO MAKE A FULL BACKUP OF ALL OF YOUR CUTENEWS FILES BEFORE YOU DO ANYTHING


Updating your current files is the most recommended way, it should leave your
hacks installed and it should be easy to do.
It can be done by uploading the 2 files inside ./update to your main cutenews
folder. Then open your browser and navigate to http://yoursite.com/cutenews/update.php
- If there are no errors, then you should be ok.
- If there is only one error about install.php, and you have already installed
  cutenews, then you most probably have deleted the install.mdu file. You may just
  ignore the error message then.
- If it gives you errors in other files, please CHMOD all files listed in
  filelist.txt to 777. If the update works after CHMOD'ing, then please CHMOD
  the files back to 644 for security reasons.
- If you are still getting error messages, are using 1.3.6, and have not
  installed any hacks/addons, then you may try to copy all files in ./replace/
  to your cutenews folder, and overwrite them.
- If you DO have hacks installed and the installed does NOT work, then please
  contact StealthEye <seye@xs4all.nl> and he might do it for you, or we will
  find some other fix.

Have fun again with CuteNews on PHP v4.3.10!

StealthEye <seye@xs4all.nl>
