<?php
function foreach_preg_callback($match) {
	if (!strstr($match[0], '=>')) {
		$match[0] = str_replace('as ', 'as $null => ', $match[0]);
		$match[0] = str_replace('as	', 'as $null =>	', $match[0]);
	}
	return $match[0];
}

$files = file('filelist.txt');
foreach ($files as $index => $file) {
	$fc = @file_get_contents(trim($file));

	if ($fc) {
		$fc = preg_replace_callback('#foreach.*#i', 'foreach_preg_callback', $fc);
	
		$fh = @fopen(trim($file), 'w+');
		if ($fh !== false) {
			if (!@fwrite($fh, $fc)) {
				echo '<strong>Could not write to file: '.$file.'</strong><br />';
			} else {
				echo 'Converted: '.$file.'<br />';
			}
			@fclose($fh);
		} else {
			echo '<strong>Could not open file for writing: '.$file.'</strong><br />';
		}
	} else {
		if (strstr($file, 'install.mdu')) {
			echo '<strong>Could not read file: '.$file.'</strong> (This is the installation file, you might have deleted it, and if you did, just ignore this message)<br />';
		} else {
			echo '<strong>Could not read file: '.$file.'</strong><br />';
		}
	}
}

?>
